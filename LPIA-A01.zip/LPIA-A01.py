base = float(input("Base?"))
altura = float(input("Altura?"))
area = base*altura

print("A área é:", area)